//
//  ViewController.swift
//  Core_data_Crud_project
//
//  Created by Shubh Ramani on 30/04/20.
//  Copyright © 2020 Shubh Ramani. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return datasourceArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")
        let person = datasourceArray[indexPath.row]
        cell?.textLabel?.text = person.name! + " " + person.lastname!
        return cell!
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
        fetchAndUpdatetable()
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete{
            let person = datasourceArray[indexPath.row]
            appDelegete.deleteRecord(person: person)
            fetchAndUpdatetable()
            
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    
        let person = datasourceArray[indexPath.row]
        var lastname: UITextField?
        var nameTextField: UITextField?
        // Declare Alert Message
        
        let dialogMessage = UIAlertController(title: "Alert Title", message: "update name and lastname", preferredStyle: .alert)
        
        //create ok button with action handler
        let ok = UIAlertAction(title: "Update", style: .default, handler: {
            (action) -> Void in
            
            
            let lastname = lastname?.text
            let name = nameTextField?.text
            
            if lastname != nil && name != nil
            {
                self.appDelegete.UpdateRecord(person: person, name: name!, lastname: lastname!)
              //  self.appDelegete.insertRecord(name: name!, lastname: lastname!)
                
                self.fetchAndUpdatetable()
                
            }
        })
        
        
        
        //create Cancle Button with actionhandler
        let cancel = UIAlertAction(title: "Cancel", style: .cancel){
            (action) -> Void in
            print("Cancel Button tapped")
        }
        
        //Add ok and cancle button to dialog message
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        
        
        //Add Input TextField to dialog message
        dialogMessage.addTextField{
            (textField) -> Void in
            nameTextField = textField
            nameTextField?.placeholder = "Type in your name"
            nameTextField?.text = person.name
            
        }
        dialogMessage.addTextField{
            (textField) -> Void in
            lastname = textField
            lastname?.placeholder = "Type in your Address"
            lastname?.text = person.lastname
        }
        //Present dialog message to user
        
        
        self.present(dialogMessage, animated: true, completion: nil)
        
        
        
    }
    
    func fetchAndUpdatetable(){
        datasourceArray = appDelegete.fetchRecords()
        tblview.reloadData()
    }
    

    var datasourceArray = [Person]()
    let appDelegete =  UIApplication.shared.delegate as! AppDelegate
            
    @IBOutlet weak var tblview: UITableView!
    
    @IBAction func addRecord(_ sender: UIButton) {
      
        var lastname: UITextField?
        var nameTextField: UITextField?
        // Declare Alert Message
        
        let dialogMessage = UIAlertController(title: "Alert Title", message: "Please Provide name and address", preferredStyle: .alert)
        
        //create ok button with action handler
        let ok = UIAlertAction(title: "ok", style: .default, handler: {
            (action) -> Void in
        
            
            let lastname = lastname?.text
            let name = nameTextField?.text
            
            if lastname != nil && name != nil
            {
               
                self.appDelegete.insertRecord(name: name!, lastname: lastname!)
            
                self.fetchAndUpdatetable()
                
            }
        })
        
    
        
        //create Cancle Button with actionhandler
        let cancel = UIAlertAction(title: "Cancel", style: .cancel){
            (action) -> Void in
            print("Cancel Button tapped")
        }
        
        //Add ok and cancle button to dialog message
        dialogMessage.addAction(ok)
        dialogMessage.addAction(cancel)
        
        
        //Add Input TextField to dialog message
        dialogMessage.addTextField{
            (textField) -> Void in
            nameTextField = textField
            nameTextField?.placeholder = "Type in your name"
            
        }
      dialogMessage.addTextField{
            (textField) -> Void in
            lastname = textField
            lastname?.placeholder = "Type in your Address"
            
        }
            //Present dialog message to user
        
        
        self.present(dialogMessage, animated: true, completion: nil)
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
}

